
<div class="container">
<div class="row">
    <h4>Title</h4>
           <?php echo $posts->just_post_title; ?>
    <h4>Description:</h4>
            <?php echo $posts->just_post_description; ?>

</div>


</div>