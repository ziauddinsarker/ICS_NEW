
            <div class="col-md-6">

                <div class="wrap">

                    <div id="chart"></div>
                </div>
            </div>

          </div><!-- /.row -->
