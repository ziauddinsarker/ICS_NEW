        <!-- Content Header (Page header) -->


        <!-- Main content -->
        <section class="content">
          <!-- Info boxes -->
          <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12">

              <h3>Contacts</h3>
              <table class="table table-bordered">
                <thead>
                <tr>
                  <th>Name</th>
                  <th>Emial Address</th>
                  <th>Phone Number</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>Ziauddin</td>
                  <td>webdesigner@simuragroup.com</td>
                  <td>01720223388</td>
                </tr>
                <tr>
                  <td>Timir</td>
                  <td>timir@simuragroup.com</td>
                  <td>01611555506</td>
                </tr>
                <tr>
                  <td>Aslam</td>
                  <td>designer@simuragroup.com</td>
                  <td>01745303275</td>
                </tr>
                </tbody>
              </table>

              </div><!-- /.info-box -->
            </div><!-- /.col -->



        </section><!-- /.content -->



