<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>
</div>
      <hr>
      <footer>
        <p>&copy; SIMURA Non-Wovens Ltd. 2015</p>
      </footer>
    </div> <!-- /container -->
	
	<script src="<?php echo base_url('assets/js/jquery-1.11.3.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/jquery-ui.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/angular.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/main.js'); ?>"></script>

</body>
</html>
